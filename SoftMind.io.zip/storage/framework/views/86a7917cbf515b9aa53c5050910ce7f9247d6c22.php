<?php $__env->startSection('content'); ?>

    <ul>
        <?php $__currentLoopData = $lampu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lamp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <li>
                <a href="Lampu/Control/<?php echo e($lamp -> id); ?>">
                    <?php echo e($lamp -> nama_lampu); ?>

                    <?php echo e($lamp -> status_lampu); ?>

                </a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SoftMind.io\resources\views/Lamp.blade.php ENDPATH**/ ?>