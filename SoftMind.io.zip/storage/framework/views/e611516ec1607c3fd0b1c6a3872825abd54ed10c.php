<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      Anything you want
    </div>
    <!-- Default to the left -->
    <strong>XI RPL - Kelompok 5 PKK &copy; 2019 <a href="#">SMKN 1 Purwosari</a>.</strong> All rights reserved.
  </footer>
<?php /**PATH C:\xampp\htdocs\SoftMind.io\resources\views/admin/footer.blade.php ENDPATH**/ ?>