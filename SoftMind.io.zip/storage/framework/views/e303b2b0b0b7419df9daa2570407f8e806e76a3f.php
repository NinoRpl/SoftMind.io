<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/user.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-name', 'Daftar Project'); ?>
<?php $__env->startSection('page-description', ''); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-5 kotak-merah" style="padding: 10px 20px">
                <h2>Tambah Data Siramin</h2>
                <form action="/home_user/tambahDataSiraminPost" method="post">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group">
                        <label for="nama">Nama Project</label>
                        <input type="text" class="inputKu" name="nama" id="nama" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <input type="hidden" class="inputKu" name="status" id="status" value="0" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label for="alamat">Alamat Project</label>
                        <input type="text" name="alamat" class="inputKu" id="alamat">
                    </div>
                    <div style="text-align: center">
                        <button type="submit" class="buttonKu">Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('kontrol-menu', 'active'); ?>
<?php $__env->startSection('fitur-menu', 'active'); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SoftMind.io\resources\views/admin/user/addLampu.blade.php ENDPATH**/ ?>