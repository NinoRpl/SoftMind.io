<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/user.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-name', 'Daftar Project'); ?>
<?php $__env->startSection('page-description', ''); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-5 kotak-merah" style="padding: 10px 20px">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h2>Edit <?php echo e($dat->nama_lampu); ?></h2>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="/home_user/kontrol/<?php echo e($dat->id); ?>/editPost" method="post">

                    <?php echo e(csrf_field()); ?>


                    <?php if($dat->status_lampu == 1): ?>
                    <div class="alert alert-info">
                        <div>Status Aktif</div>
                    </div>
                    <?php else: ?>
                    <div class="alert alert-info">
                        <div>Status NonAktif</div>
                    </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <label class="labelKu" for="nama">Nama Project</label>
                        <input type="text" class="inputKu" name="nama" id="nama" value="<?php echo e($dat->nama_lampu); ?>">
                    </div>
                    <div class="form-group">
                        <input type="hidden" class="inputKu" name="status" id="status" value="<?php echo e($dat->status_lampu); ?>">
                    </div>
                    <div class="form-group">
                        <label class="labelKu" for="alamat">Alamat Project</label>
                        <input type="text" class="inputKu" name="alamat" id="alamat" value="<?php echo e($dat->alamat_lampu); ?>">
                    </div>
                    <div style="text-align: center">
                        <button type="submit" class="buttonKu">Edit</button>
                    </div>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('kontrol-menu', 'active'); ?>
<?php $__env->startSection('fitur-menu', 'active'); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SoftMind.io\resources\views/admin/user/editData.blade.php ENDPATH**/ ?>