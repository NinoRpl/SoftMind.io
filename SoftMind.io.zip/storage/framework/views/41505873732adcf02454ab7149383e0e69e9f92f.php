<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/user.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-name', 'Controlling Project'); ?>
<?php $__env->startSection('page-description', ''); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row py-5">
        <div class="col-md-6 offset-md-2 kotak-biru text-center py-5">

            <p style="display: none !important">
                <?php echo e($hidup = 1); ?>

                <?php echo e($mati = 0); ?>

            </p>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lampu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <h2 class="my-5 py-3">Controller <?php echo e($lampu->nama_lampu); ?> </h2>

            <form action="/home_user/kontrol/<?php echo e($lampu->id); ?>/kontrolPost" method="post">

                <p style="display: none !important">
                    <?php echo e($status = $lampu -> status_lampu); ?>

                </p>

                <?php echo e(csrf_field()); ?>


                <?php if($status == 0): ?>
                    <p>Siramin Mati</p>
                <?php else: ?>
                    <p>Siramin Hidup</p>
                <?php endif; ?>

                <input type="hidden" name="id" class="my-3 d-block mx-auto" id="id" value="<?php echo e($lampu -> id); ?>">
                <input type="hidden" name="nama_lampu" class="my-3 d-block mx-auto" id="id" value="<?php echo e($lampu -> nama_lampu); ?>">
                <input type="hidden" name="alamat_lampu" class="my-3 d-block mx-auto" id="id" value="<?php echo e($lampu -> alamat_lampu); ?>">

                <div style="display: inline; text-align: center">
                    Kode Status :
                    <input type="hidden" name="status_lampu" style="display: none !important" class="my-3 d-block mx-auto" id="status" value=
                    <?php if(($lampu -> status_lampu) == 0): ?>
                        "1"
                    <?php else: ?>
                        "0"
                    <?php endif; ?>
                    >
                </div>

                <p class="d-none">
                    <?php echo e($status = $lampu -> status_lampu); ?>

                </p>
                <button type="submit" class="btn btn-primary d-block mx-auto px-5">
                    <?php if($status == 0): ?>
                        Hidupkan
                    <?php else: ?>
                        Matikan
                    <?php endif; ?>
                </button>
            </form>
            <div class="d-flex fiturPerData">
                    <button id="hapus"><i class="fa fa-trash"></i></button>
                    <button id="edit"><i class="fa fa-edit"></i></button>
                </div>

                <script>
                    var hapus = document.getElementById('hapus'),
                    edit = document.getElementById('edit');

                    hapus.addEventListener('click', function(){
                        var tanya = confirm('Yakin Dihapus ?');
                        if(tanya == true) {
                            document.location.href='/home_user/kontrol/'+<?php echo e($lampu->id); ?>+'/hapus';
                        } else {
                            alert('Penghapusan Batal');
                        }
                    });
                    edit.addEventListener('click', function(){
                        document.location.href='/home_user/kontrol/'+<?php echo e($lampu->id); ?>+'/edit';
                    });

                </script>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('kontrol-menu', 'active'); ?>
<?php $__env->startSection('fitur-menu', 'active'); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SoftMind.io\resources\views/admin/user/controlling.blade.php ENDPATH**/ ?>