<?php $__env->startSection('css'); ?>
  <style>
      nav, #footer {
        display: none !important;
      }
      body {
        background-image: linear-gradient(to right bottom, #01aff8 ,#006f9e) !important;
      }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', ' - Register'); ?>
<?php $__env->startSection('content'); ?>

    <img src="../img/sans/illust1.png" class="position-fixed img-login-animate" width="100%" alt="">

    <div class="bunder-signup">
        <div class="bunder-animate-signup"></div>
        <div class="bunder-animate-signup"></div>
        <div class="bunder-animate-signup"></div>
    </div>

    <div class="bunder-bottom-signup">
        <div class="bunder-bottom-animate-signup"></div>
        <div class="bunder-bottom-animate-signup"></div>
        <div class="bunder-bottom-animate-signup"></div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-lg-6 position-relative signup text-center my-5 px-4 py-5 offset-md-3">
                <h2>Daftar</h2>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-10 signup-form offset-md-1 text-left">
                        <form action="<?php echo e(url('/signupPost')); ?>" method="post" enctype="multipart/form-data">

                            <?php echo e(csrf_field()); ?>


                            <div class="form-group">
                                <label for="nama">Nama</label>
                                <input type="text" class="form-control" name="nama" id="nama" autofocus>
                            </div>

                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" name="password" id="password">
                            </div>

                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" name="email" id="email">
                            </div>

                            <div class="form-group">
                                <label for="alamat">Alamat</label>
                                <input type="text" name="alamat" id="alamat">
                            </div>

                            <div class="form-group">
                                <label for="profesi">Profesi</label>
                                <input type="text" name="profesi" class="form-control" id="profesi">
                            </div>

                            <div class="form-group">
                                <label for="gambar">Foto Profil</label>
                                <input type="file" name="gambar" class="form-control" id="gambar">
                            </div>

                            <div class="text-center">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary my-4 px-5">Daftar</button>
                                </div>
                                <hr>
                                Anda sudah punya akun ? <a href="<?php echo e(url('signin')); ?>">Masuk</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SoftMind.io\resources\views/auth/register.blade.php ENDPATH**/ ?>