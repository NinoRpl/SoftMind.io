<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/user.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-name', 'Daftar Project'); ?>
<?php $__env->startSection('page-description', ''); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <h2>Data Siramin</h2>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lampu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="kotak-biru">
                        <a href="/home_user/kontrol/<?php echo e($lampu->id); ?>">
                            <h4><?php echo e($lampu -> nama_lampu); ?></h4>
                            <?php if($lampu -> status_lampu == 1): ?>
                                <p>Status Hidup</p>
                            <?php else: ?>
                                <p>Status Mati</p>
                            <?php endif; ?>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <a href="/home_user/tambahDataSiramin">
            <div class="btn-tambahSiramin">
                <i class="fa fa-plus"></i>
            </div>
        </a>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('kontrol-menu', 'active'); ?>
<?php $__env->startSection('fitur-menu', 'active'); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SoftMind.io\resources\views/admin/user/dataLampu.blade.php ENDPATH**/ ?>