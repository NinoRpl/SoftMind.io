<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row py-5">
            <div class="col-12 text-center py-5">
                <h2 class="my-5 py-3">Controller Lampu</h2>

                <p class="d-none">
                    <?php echo e($hidup = 1); ?>

                    <?php echo e($mati = 0); ?>

                </p>

                <?php $__currentLoopData = $lampu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <form action="/Lampu/Control/update" method="post">

                    <p class="d-none">
                        <?php echo e($status = $lam -> status_lampu); ?>

                    </p>

                    <?php echo e(csrf_field()); ?>


                    <?php if($status == 0): ?>
                        <p>Lampu Mati</p>
                    <?php else: ?>
                        <p>Lampu Hidup</p>
                    <?php endif; ?>

                    <input type="hidden" name="id" class="my-3 d-block mx-auto" id="id" value="<?php echo e($lam -> id); ?>">
                    <input type="hidden" name="nama_lampu" class="my-3 d-block mx-auto" id="id" value="<?php echo e($lam -> nama_lampu); ?>">
                    <input type="hidden" name="alamat_lampu" class="my-3 d-block mx-auto" id="id" value="<?php echo e($lam -> alamat_lampu); ?>">

                    <input type="hidden" name="status_lampu" class="my-3 d-block mx-auto" id="status" value=
                    <?php if(($lam -> status_lampu) == 0): ?>
                        "1"
                    <?php else: ?>
                        "0"
                    <?php endif; ?>
                    >

                    <p class="d-none">
                        <?php echo e($status = $lam -> statusphp_lampu); ?>

                    </p>

                    <button type="submit" class="btn btn-primary d-block mx-auto px-5">
                        <?php if($status == 0): ?>
                            Hidupkan
                        <?php else: ?>
                            Matikan
                        <?php endif; ?>
                    </button>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SoftMind.io\resources\views/Lampu.blade.php ENDPATH**/ ?>